exports.calculate = function(expression) {
  return 0;
}

